﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPT_Winform
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        SqlDataReader dr;

        public Form1()
        {
            InitializeComponent();
            


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            fYP_GroupBindingSource.DataSource = new FYP_Group();
            domainComboBox.Items.Add("AI");


            con.ConnectionString = "Server=DESKTOP-70ITJ84; Database=IPT_FYP_Project; Trusted_Connection=true;MultipleActiveResultSets=true;TrustServerCertificate=True";
            con.Open();
            com.Connection = con;
            com.CommandText = "SET IDENTITY_INSERT FYP_Group OFF;";
            com.ExecuteNonQuery();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            fYP_GroupBindingSource.EndEdit();
            FYP_Group group = fYP_GroupBindingSource.Current as FYP_Group;

            //MessageBox.Show(group.Leader_ID, "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            if (group != null)
            {
                ValidationContext context = new ValidationContext(group, null, null);
                IList<ValidationResult> errors = new List<ValidationResult>();

                if (!Validator.TryValidateObject(group, context, errors, true))
                {
                    foreach (ValidationResult result in errors)
                    {
                        MessageBox.Show(result.ErrorMessage, "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    return;
                }
                group.Status = "Pending";
                com.CommandText = String.Format("INSERT INTO FYP_Group(Leader_ID,Leader_Name,Member1_ID,Member1_Name,Member2_ID,Member2_Name,Supervisor_Name,Supervisor_ID,Domain,FYP_Status)" +
                    "VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}'," +
                    "'{9}')", group.Leader_ID,group.Leader_Name,group.Member2_ID,group.Member2_Name,group.Member3_ID,group.Member3_Name,group.Supervisor_Name,
                    group.Supervisor_Email,group.Domain,group.Status);
                com.ExecuteNonQuery();
                con.Close();
            }
            this.Close();
        }
        bool check_groups(FYP_Group group)
        {

            com.CommandText = "SELECT Leader_ID,Member1_ID,Member2_ID FROM FYP_Group";
            SqlDataReader dr = com.ExecuteReader();

            while (dr.Read())
            {
                Console.WriteLine("{0} {1} {2}", dr.GetString(0), dr.GetString(1), dr.GetString(2));

            }

            return true;
        }
        private void supervisor_NameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void supervisor_NameLabel_Click(object sender, EventArgs e)
        {

        }

        private void fYP_GroupBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void fYP_GroupBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void domainComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
