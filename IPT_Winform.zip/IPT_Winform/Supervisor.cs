﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPT_Winform
{
    public partial class Supervisor : Form
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        SqlDataReader dr;
        public Supervisor()
        {
            //con.ConnectionString = "Server=DESKTOP-70ITJ84; Database=IPT_FYP_Project; Trusted_Connection=true;MultipleActiveResultSets=true;TrustServerCertificate=True";
            //con.Open();
            //com.Connection = con;

            //com.CommandText = "SELECT Leader_ID,Leader_Name,Domain FROM [IPT_FYP_Project].[dbo].[FYP_Group] WHERE Supervisor_ID = 'rauf';";
            //SqlDataReader dr = com.ExecuteReader();
            //Label label2 = new Label();
            //bool flag = false;
            //label2.Text = "";
            //while (dr.Read())
            //{
                
            //    label2.Text += dr.GetString(0);
            //    label2.Text += dr.GetString(1);
            //    label2.Text += System.Environment.NewLine;
            //    flag = true;
            //}
            //if (flag==false)
            //    label2.Text = "HHH";
            //label2.Visible = true;

            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            string supervisor_ID = "Rauf";
            dataGridView1.AutoGenerateColumns = true;
           
            using (SqlConnection con = new SqlConnection("Server=DESKTOP-70ITJ84; Database=IPT_FYP_Project; Trusted_Connection=true;MultipleActiveResultSets=true;TrustServerCertificate=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Leader_ID,Leader_Name,Domain,FYP_Status FROM [IPT_FYP_Project].[dbo].[FYP_Group] WHERE Supervisor_ID = 'Rauf';", con);
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds,"FYP_Group");

                //dataGridView1.DataSource = ds;
                dataGridView1.DataSource = ds.Tables["FYP_Group"].DefaultView;

                con.Close();
                // dataGridView1.DataBind();
                //dataGridView1.DataBind();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
