﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPT_Winform
{
    public partial class Home : Form
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        SqlDataReader dr;

        public Home()
        {

            con.ConnectionString = "Server=DESKTOP-70ITJ84; Database=IPT_FYP_Project; Trusted_Connection=true;MultipleActiveResultSets=true;TrustServerCertificate=True";
            con.Open();
            com.Connection = con;

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Form reg = new Form1();

            reg.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            textBox1.Visible = true;
            button3.Visible = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            com.CommandText = "SELECT Leader_ID,FYP_Status FROM FYP_Group";
            SqlDataReader dr = com.ExecuteReader();
            bool flag = false;
            while (dr.Read())
            {



                if (textBox1.Text.Equals(dr.GetString(0)))
                {
                    //Console.WriteLine(dr.GetString(0));
                    string message = dr.GetString(1);
                    string title = "Status";
                    MessageBox.Show(message, title);
                    flag = true;
                }
            }
            if (flag == false)
            {
                string message = "Leader ID not registered";
                string title = "Status";
                MessageBox.Show(message, title);
            }
            dr.Close();
        }
    }
    //    private void button4_Click(object sender, EventArgs e)
    //    {
    //        textBox2.Visible = true;
    //        button5.Visible = true;

    //    }

    //    private void button5_Click()
    //    {
    //        List<FYP_Group> models = new List<FYP_Group>();
    //        FYP_Group model = new FYP_Group();
    //        con.Open();
    //        com.Connection = con;
    //        string supervisor_id = textBox2.Text;

    //        //com.CommandText = "SELECT Leader_ID,Leader_Name,Domain FROM [IPT_FYP_Project].[dbo].[FYP_Group] WHERE Supervisor_ID = '" + supervisor_id + "'";
    //        //dr = com.ExecuteReader();
    //        //while (dr.Read())
    //        //{
    //        //    model.Leader_ID = dr.GetString(0);
    //        //    model.Leader_Name = dr.GetString(1);
    //        //    model.Domain = dr.GetString(2);
    //        //    models.Add(model);
    //        //}

    //    }

    //    private void button5_Click(object sender, EventArgs e)
    //    {
    //        Form sup = new Supervisor();
    //        sup.Show();
    //    }
    //}
}
