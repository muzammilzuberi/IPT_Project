﻿
namespace IPT_Winform
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label leader_IDLabel;
            System.Windows.Forms.Label leader_NameLabel;
            System.Windows.Forms.Label member2_IDLabel;
            System.Windows.Forms.Label member2_NameLabel;
            System.Windows.Forms.Label member3_IDLabel;
            System.Windows.Forms.Label member3_NameLabel;
            System.Windows.Forms.Label supervisor_EmailLabel;
            System.Windows.Forms.Label supervisor_NameLabel;
            System.Windows.Forms.Label domainLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.fYP_GroupBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.fYP_GroupBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.leader_IDTextBox = new System.Windows.Forms.TextBox();
            this.leader_NameTextBox = new System.Windows.Forms.TextBox();
            this.member2_IDTextBox = new System.Windows.Forms.TextBox();
            this.member2_NameTextBox = new System.Windows.Forms.TextBox();
            this.member3_IDTextBox = new System.Windows.Forms.TextBox();
            this.member3_NameTextBox = new System.Windows.Forms.TextBox();
            this.supervisor_EmailTextBox = new System.Windows.Forms.TextBox();
            this.supervisor_NameTextBox = new System.Windows.Forms.TextBox();
            this.domainComboBox = new System.Windows.Forms.ComboBox();
            this.fYP_GroupBindingSource = new System.Windows.Forms.BindingSource(this.components);
            leader_IDLabel = new System.Windows.Forms.Label();
            leader_NameLabel = new System.Windows.Forms.Label();
            member2_IDLabel = new System.Windows.Forms.Label();
            member2_NameLabel = new System.Windows.Forms.Label();
            member3_IDLabel = new System.Windows.Forms.Label();
            member3_NameLabel = new System.Windows.Forms.Label();
            supervisor_EmailLabel = new System.Windows.Forms.Label();
            supervisor_NameLabel = new System.Windows.Forms.Label();
            domainLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fYP_GroupBindingNavigator)).BeginInit();
            this.fYP_GroupBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fYP_GroupBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // leader_IDLabel
            // 
            leader_IDLabel.AutoSize = true;
            leader_IDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            leader_IDLabel.Location = new System.Drawing.Point(74, 50);
            leader_IDLabel.Name = "leader_IDLabel";
            leader_IDLabel.Size = new System.Drawing.Size(106, 24);
            leader_IDLabel.TabIndex = 18;
            leader_IDLabel.Text = "Leader ID:";
            // 
            // leader_NameLabel
            // 
            leader_NameLabel.AutoSize = true;
            leader_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            leader_NameLabel.Location = new System.Drawing.Point(74, 91);
            leader_NameLabel.Name = "leader_NameLabel";
            leader_NameLabel.Size = new System.Drawing.Size(142, 24);
            leader_NameLabel.TabIndex = 20;
            leader_NameLabel.Text = "Leader Name:";
            // 
            // member2_IDLabel
            // 
            member2_IDLabel.AutoSize = true;
            member2_IDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            member2_IDLabel.Location = new System.Drawing.Point(74, 134);
            member2_IDLabel.Name = "member2_IDLabel";
            member2_IDLabel.Size = new System.Drawing.Size(129, 24);
            member2_IDLabel.TabIndex = 22;
            member2_IDLabel.Text = "Member2 ID:";
            // 
            // member2_NameLabel
            // 
            member2_NameLabel.AutoSize = true;
            member2_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            member2_NameLabel.Location = new System.Drawing.Point(74, 179);
            member2_NameLabel.Name = "member2_NameLabel";
            member2_NameLabel.Size = new System.Drawing.Size(165, 24);
            member2_NameLabel.TabIndex = 24;
            member2_NameLabel.Text = "Member2 Name:";
            // 
            // member3_IDLabel
            // 
            member3_IDLabel.AutoSize = true;
            member3_IDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            member3_IDLabel.Location = new System.Drawing.Point(74, 220);
            member3_IDLabel.Name = "member3_IDLabel";
            member3_IDLabel.Size = new System.Drawing.Size(129, 24);
            member3_IDLabel.TabIndex = 26;
            member3_IDLabel.Text = "Member3 ID:";
            // 
            // member3_NameLabel
            // 
            member3_NameLabel.AutoSize = true;
            member3_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            member3_NameLabel.Location = new System.Drawing.Point(74, 264);
            member3_NameLabel.Name = "member3_NameLabel";
            member3_NameLabel.Size = new System.Drawing.Size(165, 24);
            member3_NameLabel.TabIndex = 28;
            member3_NameLabel.Text = "Member3 Name:";
            // 
            // supervisor_EmailLabel
            // 
            supervisor_EmailLabel.AutoSize = true;
            supervisor_EmailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            supervisor_EmailLabel.Location = new System.Drawing.Point(74, 304);
            supervisor_EmailLabel.Name = "supervisor_EmailLabel";
            supervisor_EmailLabel.Size = new System.Drawing.Size(174, 24);
            supervisor_EmailLabel.TabIndex = 30;
            supervisor_EmailLabel.Text = "Supervisor Email:";
            // 
            // supervisor_NameLabel
            // 
            supervisor_NameLabel.AutoSize = true;
            supervisor_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            supervisor_NameLabel.Location = new System.Drawing.Point(74, 344);
            supervisor_NameLabel.Name = "supervisor_NameLabel";
            supervisor_NameLabel.Size = new System.Drawing.Size(177, 24);
            supervisor_NameLabel.TabIndex = 32;
            supervisor_NameLabel.Text = "Supervisor Name:";
            supervisor_NameLabel.Click += new System.EventHandler(this.supervisor_NameLabel_Click);
            // 
            // domainLabel
            // 
            domainLabel.AutoSize = true;
            domainLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            domainLabel.Location = new System.Drawing.Point(120, 390);
            domainLabel.Name = "domainLabel";
            domainLabel.Size = new System.Drawing.Size(87, 24);
            domainLabel.TabIndex = 33;
            domainLabel.Text = "Domain:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(163, 454);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(274, 38);
            this.button1.TabIndex = 16;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // fYP_GroupBindingNavigator
            // 
            this.fYP_GroupBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.fYP_GroupBindingNavigator.BindingSource = this.fYP_GroupBindingSource;
            this.fYP_GroupBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.fYP_GroupBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.fYP_GroupBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.fYP_GroupBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.fYP_GroupBindingNavigatorSaveItem});
            this.fYP_GroupBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.fYP_GroupBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.fYP_GroupBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.fYP_GroupBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.fYP_GroupBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.fYP_GroupBindingNavigator.Name = "fYP_GroupBindingNavigator";
            this.fYP_GroupBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.fYP_GroupBindingNavigator.Size = new System.Drawing.Size(820, 27);
            this.fYP_GroupBindingNavigator.TabIndex = 17;
            this.fYP_GroupBindingNavigator.Text = "bindingNavigator1";
            this.fYP_GroupBindingNavigator.RefreshItems += new System.EventHandler(this.fYP_GroupBindingNavigator_RefreshItems);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // fYP_GroupBindingNavigatorSaveItem
            // 
            this.fYP_GroupBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fYP_GroupBindingNavigatorSaveItem.Enabled = false;
            this.fYP_GroupBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("fYP_GroupBindingNavigatorSaveItem.Image")));
            this.fYP_GroupBindingNavigatorSaveItem.Name = "fYP_GroupBindingNavigatorSaveItem";
            this.fYP_GroupBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.fYP_GroupBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // leader_IDTextBox
            // 
            this.leader_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Leader_ID", true));
            this.leader_IDTextBox.Location = new System.Drawing.Point(288, 52);
            this.leader_IDTextBox.Name = "leader_IDTextBox";
            this.leader_IDTextBox.Size = new System.Drawing.Size(232, 22);
            this.leader_IDTextBox.TabIndex = 19;
            // 
            // leader_NameTextBox
            // 
            this.leader_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Leader_Name", true));
            this.leader_NameTextBox.Location = new System.Drawing.Point(288, 93);
            this.leader_NameTextBox.Name = "leader_NameTextBox";
            this.leader_NameTextBox.Size = new System.Drawing.Size(232, 22);
            this.leader_NameTextBox.TabIndex = 21;
            // 
            // member2_IDTextBox
            // 
            this.member2_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Member2_ID", true));
            this.member2_IDTextBox.Location = new System.Drawing.Point(288, 136);
            this.member2_IDTextBox.Name = "member2_IDTextBox";
            this.member2_IDTextBox.Size = new System.Drawing.Size(232, 22);
            this.member2_IDTextBox.TabIndex = 23;
            // 
            // member2_NameTextBox
            // 
            this.member2_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Member2_Name", true));
            this.member2_NameTextBox.Location = new System.Drawing.Point(288, 181);
            this.member2_NameTextBox.Name = "member2_NameTextBox";
            this.member2_NameTextBox.Size = new System.Drawing.Size(232, 22);
            this.member2_NameTextBox.TabIndex = 25;
            // 
            // member3_IDTextBox
            // 
            this.member3_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Member3_ID", true));
            this.member3_IDTextBox.Location = new System.Drawing.Point(288, 222);
            this.member3_IDTextBox.Name = "member3_IDTextBox";
            this.member3_IDTextBox.Size = new System.Drawing.Size(232, 22);
            this.member3_IDTextBox.TabIndex = 27;
            // 
            // member3_NameTextBox
            // 
            this.member3_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Member3_Name", true));
            this.member3_NameTextBox.Location = new System.Drawing.Point(288, 266);
            this.member3_NameTextBox.Name = "member3_NameTextBox";
            this.member3_NameTextBox.Size = new System.Drawing.Size(232, 22);
            this.member3_NameTextBox.TabIndex = 29;
            // 
            // supervisor_EmailTextBox
            // 
            this.supervisor_EmailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Supervisor_Email", true));
            this.supervisor_EmailTextBox.Location = new System.Drawing.Point(288, 306);
            this.supervisor_EmailTextBox.Name = "supervisor_EmailTextBox";
            this.supervisor_EmailTextBox.Size = new System.Drawing.Size(232, 22);
            this.supervisor_EmailTextBox.TabIndex = 31;
            // 
            // supervisor_NameTextBox
            // 
            this.supervisor_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Supervisor_Name", true));
            this.supervisor_NameTextBox.Location = new System.Drawing.Point(288, 346);
            this.supervisor_NameTextBox.Name = "supervisor_NameTextBox";
            this.supervisor_NameTextBox.Size = new System.Drawing.Size(232, 22);
            this.supervisor_NameTextBox.TabIndex = 33;
            this.supervisor_NameTextBox.TextChanged += new System.EventHandler(this.supervisor_NameTextBox_TextChanged);
            // 
            // domainComboBox
            // 
            this.domainComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.fYP_GroupBindingSource, "Domain", true));
            this.domainComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.domainComboBox.FormattingEnabled = true;
            this.domainComboBox.Location = new System.Drawing.Point(288, 392);
            this.domainComboBox.Name = "domainComboBox";
            this.domainComboBox.Size = new System.Drawing.Size(232, 24);
            this.domainComboBox.TabIndex = 34;
            this.domainComboBox.SelectedIndexChanged += new System.EventHandler(this.domainComboBox_SelectedIndexChanged);
            // 
            // fYP_GroupBindingSource
            // 
            this.fYP_GroupBindingSource.DataSource = typeof(IPT_Winform.FYP_Group);
            this.fYP_GroupBindingSource.CurrentChanged += new System.EventHandler(this.fYP_GroupBindingSource_CurrentChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 519);
            this.Controls.Add(domainLabel);
            this.Controls.Add(this.domainComboBox);
            this.Controls.Add(leader_IDLabel);
            this.Controls.Add(this.leader_IDTextBox);
            this.Controls.Add(leader_NameLabel);
            this.Controls.Add(this.leader_NameTextBox);
            this.Controls.Add(member2_IDLabel);
            this.Controls.Add(this.member2_IDTextBox);
            this.Controls.Add(member2_NameLabel);
            this.Controls.Add(this.member2_NameTextBox);
            this.Controls.Add(member3_IDLabel);
            this.Controls.Add(this.member3_IDTextBox);
            this.Controls.Add(member3_NameLabel);
            this.Controls.Add(this.member3_NameTextBox);
            this.Controls.Add(supervisor_EmailLabel);
            this.Controls.Add(this.supervisor_EmailTextBox);
            this.Controls.Add(supervisor_NameLabel);
            this.Controls.Add(this.supervisor_NameTextBox);
            this.Controls.Add(this.fYP_GroupBindingNavigator);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fYP_GroupBindingNavigator)).EndInit();
            this.fYP_GroupBindingNavigator.ResumeLayout(false);
            this.fYP_GroupBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fYP_GroupBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource fYP_GroupBindingSource;
        private System.Windows.Forms.BindingNavigator fYP_GroupBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton fYP_GroupBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox leader_IDTextBox;
        private System.Windows.Forms.TextBox leader_NameTextBox;
        private System.Windows.Forms.TextBox member2_IDTextBox;
        private System.Windows.Forms.TextBox member2_NameTextBox;
        private System.Windows.Forms.TextBox member3_IDTextBox;
        private System.Windows.Forms.TextBox member3_NameTextBox;
        private System.Windows.Forms.TextBox supervisor_EmailTextBox;
        private System.Windows.Forms.TextBox supervisor_NameTextBox;
        private System.Windows.Forms.ComboBox domainComboBox;
    }
}

