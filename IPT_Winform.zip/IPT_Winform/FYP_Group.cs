﻿using Microsoft.Build.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;

namespace IPT_Winform
{
    class FYP_Group
    {
        [Required]

        public string Leader_Name { get; set; }
        [Required]
        [RegularExpression("\\d{2}\\w-\\d{4}", ErrorMessage = "Please Enter Valid Leader ID")]

        public string Leader_ID { get; set; }
        [Required]
        [RegularExpression ("[\\w ]*")]
        public string Member2_Name { get; set; }

        [Required]
        [RegularExpression("\\d{2}\\w-\\d{4}", ErrorMessage = "Please Enter Valid Member 1 ID")]

        public string Member2_ID { get; set; }

        [Required]
        [RegularExpression("[\\w ]*")]
        public string Member3_Name { get; set; }

        [Required]
        [RegularExpression("\\d{2}\\w-\\d{4}", ErrorMessage = "Please Enter Valid Member 2 ID")]
        public string Member3_ID { get; set; }

        [Required]
        [RegularExpression("[\\w ]*")]
        public string Supervisor_Name { get; set; }

        [Required]
        [RegularExpression("[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", ErrorMessage = "Please Enter Valid Email")]
        public string Supervisor_Email { get; set; }

        [Required]
        [RegularExpression("[\\w ]*")]
        public string Domain { get; set; }

        public string Status { get; set; }
    }

}

