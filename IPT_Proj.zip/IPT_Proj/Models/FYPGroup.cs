﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;


namespace IPT_Proj.Models
{
    public class FYPGroup
    {
        [Required]
        public string Leader_Name { get; set; }

        [Required]
        public string Leader_ID { get; set; }
        public string Member2_Name { get; set; }
        public string Member2_ID { get; set; }
        public string Member3_Name { get; set; }
        public string Member3_ID { get; set; }

        public string Supervisor_Name { get; set; }
        [Required]
        [RegularExpression(".+\\@.+\\..", ErrorMessage = "Please Enter Valid Email")]

        public string Supervisor_Email { get; set; }
        public string Domain { get; set; }
        public string fyp_status { get; set; }


    }
}