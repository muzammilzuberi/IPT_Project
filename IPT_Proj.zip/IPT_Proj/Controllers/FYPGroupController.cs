﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using IPT_Proj.Models;
using System.Windows.Forms;

namespace IPT_Proj.Controllers
{
    public class FYPGroupController : Controller
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        SqlDataReader dr;
        
        //FYPGroupController()
        //{

        //    connectionString();
        //}

        // GET: Group
        [HttpGet]
        public ActionResult Registration()
        {
            FYPGroup model = new FYPGroup();
            return View(model);
        }

     
        public ActionResult Check_Status(FYPGroup model)
        {
            connectionString();
            con.Open();
            com.Connection = con;
            string leader_id = model.Leader_ID;
            com.CommandText = "SELECT FYP_Status FROM [IPT_FYP_Project].[dbo].[FYP_Group] WHERE Leader_ID = '" + leader_id +"'";
            dr = com.ExecuteReader();
            string fyp_status="";
            while (dr.Read())
            {
                fyp_status= dr.GetString(0);
            }
            if (fyp_status == "")
                fyp_status = "Not Available";
            ViewBag.status = fyp_status;
            dr.Close();
            return View("Check_Status");
        }

        public ActionResult homepage()
        {
            FYPGroup model = new FYPGroup();
            return View("homepage");
        }

        void connectionString()
        {
            con.ConnectionString = "Server=DESKTOP-70ITJ84; Database=Login; Trusted_Connection=true;MultipleActiveResultSets=true;TrustServerCertificate=True";
        }
        [HttpGet]
        public ActionResult Next()
        {

            return View("Index");
        }

        public ActionResult Supervisor(FYPGroup m)
        {

            List <FYPGroup> models = new List<FYPGroup>();
            int i = 0;
            FYPGroup model = new FYPGroup();
            connectionString();
            con.Open();
            com.Connection = con;
            string supervisor_id = m.Supervisor_Email;

            com.CommandText = "SELECT Leader_ID,Leader_Name,Domain FROM [IPT_FYP_Project].[dbo].[FYP_Group] WHERE Supervisor_ID = '" + supervisor_id + "'";
            dr = com.ExecuteReader();
            while(dr.Read())
            {
                model.Leader_ID = dr.GetString(0);
                model.Leader_Name = dr.GetString(1);
                model.Domain = dr.GetString(2);
                models.Add(model);
            }
            return View("Supervisor",models);
        }

        public ActionResult Change_status(System.Web.Mvc.FormCollection form)
        {
            string relocate = form["isActive"];

            connectionString();
            con.Open();
            com.Connection = con;
            //com.CommandText = "SELECT Leader_ID,Leader_Name,Domain FROM [IPT_FYP_Project].[dbo].[FYP_Group] WHERE Supervisor_ID = '" + supervisor_id + "'";

            return View("homepage");
        }
    }
}