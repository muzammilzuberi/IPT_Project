﻿using IPT_Proj.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IPT_Proj.Controllers
{
    public class CreateController : Controller
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        SqlDataReader dr;

        // GET: Create
        void connectionString()
        {
            con.ConnectionString = "Server=DESKTOP-70ITJ84; Database=IPT_FYP_Project; Trusted_Connection=true;MultipleActiveResultSets=true;TrustServerCertificate=True";
        }

        public ActionResult give_status(FYPGroup model)
        {
            connectionString();
            con.Open();
            com.Connection = con;
            model.Supervisor_Email = "Rauf";
            com.CommandText = String.Format("UPDATE [IPT_FYP_Project].[dbo].[FYP_Group] SET FYP_Status = '" + model.fyp_status +"' WHERE Supervisor_ID = '"+ model.Supervisor_Email+"' ");
            com.ExecuteNonQuery();
            con.Close();
            //Console.WriteLine(model.Leader_Name);
            //ViewBag.MyMessage = model.fyp_status;



            return View("homepage");
        }

        public ActionResult Validate(FYPGroup model)
        {
            connectionString();
            con.Open();
            com.Connection = con;
            //com.CommandText = String.Format("INSERT INTO FYP_Group(Leader_ID,Leader_Name,Member1_ID,Member1_Name,Member2_ID,Member2_Name,Supervisor_Name,Supervisor_ID,Domain)" +
            //    "VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}'," +
            //    "'{8}')", form["Leader_ID"], form["Leader_Name"], form["Member2_ID"], form["Member2_Name"], form["Member3_ID"], form["Member3_Name"], form["Supervisor_Name"],
            //    form["Supervisor_Email"], form["Domain"]);
            com.CommandText = String.Format("INSERT INTO [IPT_FYP_Project].[dbo].[FYP_Group](Leader_ID,Leader_Name,Member1_ID,Member1_Name,Member2_ID,Member2_Name,Supervisor_Name,Supervisor_ID,Domain)" +
                "VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}'," +
                "'{8}')", model.Leader_ID, model.Leader_Name, model.Member2_ID, model.Member2_Name, model.Member3_ID, model.Member3_Name, model.Supervisor_Name,
                model.Supervisor_Email);

            com.ExecuteNonQuery();
            con.Close();
            //Console.WriteLine(model.Leader_Name);
            ViewBag.MyMessage = model.Leader_Name;
            return View("Create");
        }
        public ActionResult Create()
        {

            return View();
            //connectionString();
            //con.Open();
            //com.Connection = con;
            //com.CommandText = "select * from FYP_Group";
            //con.Close();
            //dr = com.ExecuteReader();

            //if (dr.Read())
            //{
            //    con.Close();
            //    return View("Create");
            //}

            //else
            //{
            //    con.Close();
            //    return View("Create");
            //}
        }

    }
}